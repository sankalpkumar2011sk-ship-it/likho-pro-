import fs from 'node:fs';
import path from 'node:path';

const root = 'android';
const javaRoot = path.join(root, 'app/src/main/java/com/likhopro/app');
fs.mkdirSync(javaRoot, { recursive: true });
for (const file of ['MainActivity.java', 'NativeFilesPlugin.java']) {
  const source = path.join('android-template/app/src/main/java/com/likhopro/app', file);
  fs.copyFileSync(source, path.join(javaRoot, file));
}
const resXml = path.join(root, 'app/src/main/res/xml');
fs.mkdirSync(resXml, { recursive: true });
fs.copyFileSync('android-template/app/src/main/res/xml/file_paths.xml', path.join(resXml, 'file_paths.xml'));

const manifestPath = path.join(root, 'app/src/main/AndroidManifest.xml');
let manifest = fs.readFileSync(manifestPath, 'utf8');
manifest = manifest.replace(/\s*<uses-permission android:name="android.permission.INTERNET"\s*\/>/g, '');
manifest = manifest.replace(/<application\b/, '<application android:usesCleartextTraffic="false"');
manifest = manifest.replace(/(<activity\b[^>]*android:name="[^"]*MainActivity"[^>]*)(>)/, (m, a, b) => {
  if (!a.includes('android:launchMode')) a += ' android:launchMode="singleTask"';
  return a + b;
});
const filters = [
  'application/pdf',
  'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
  'application/msword',
  'text/plain',
  'text/markdown',
  'text/html',
  'application/rtf',
  'application/vnd.openxmlformats-officedocument.presentationml.presentation',
  'application/vnd.ms-powerpoint',
  'image/*'
].map(mime => `
        <intent-filter>
            <action android:name="android.intent.action.VIEW" />
            <category android:name="android.intent.category.DEFAULT" />
            <data android:mimeType="${mime}" />
        </intent-filter>
        <intent-filter>
            <action android:name="android.intent.action.SEND" />
            <category android:name="android.intent.category.DEFAULT" />
            <data android:mimeType="${mime}" />
        </intent-filter>`).join('');
manifest = manifest.replace(/(<activity\b[^>]*android:name="[^"]*MainActivity"[^>]*>)/, `$1${filters}`);
const provider = `
        <provider
            android:name="androidx.core.content.FileProvider"
            android:authorities="${'${applicationId}'}.fileprovider"
            android:exported="false"
            android:grantUriPermissions="true">
            <meta-data
                android:name="android.support.FILE_PROVIDER_PATHS"
                android:resource="@xml/file_paths" />
        </provider>
`;
manifest = manifest.replace('</application>', provider + '\\n    </application>');
fs.writeFileSync(manifestPath, manifest);

const gradleFiles = [
  path.join(root, 'app/build.gradle'),
  path.join(root, 'app/build.gradle.kts')
];
for (const gradlePath of gradleFiles) {
  if (!fs.existsSync(gradlePath)) continue;
  let g = fs.readFileSync(gradlePath, 'utf8');
  if (!g.includes('androidx.core:core:')) {
    const dep = gradlePath.endsWith('.kts')
      ? '\\n    implementation("androidx.core:core:1.15.0")\\n'
      : "\\n    implementation 'androidx.core:core:1.15.0'\\n";
    g = g.replace(/dependencies\s*\{/, match => match + dep);
    fs.writeFileSync(gradlePath, g);
  }
}
console.log('Android native file integration patched.');
