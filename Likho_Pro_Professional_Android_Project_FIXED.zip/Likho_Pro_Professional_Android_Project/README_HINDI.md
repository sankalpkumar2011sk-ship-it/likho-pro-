# Likho Pro — Professional Offline Android Project

यह GitHub से Android APK बनाने के लिए तैयार किया गया प्रोजेक्ट है। इसमें आपका मौजूदा `likho pro final.html` शामिल है।

## क्या शामिल है

- Capacitor Android container
- Offline HTML app assets (`www/index.html`)
- Native Android File Picker (`ACTION_OPEN_DOCUMENT`)
- Android File Manager से `Open with Likho Pro` के लिए MIME intent filters
- Android से incoming `content://` URI पढ़ने का Native plugin
- Save As (`ACTION_CREATE_DOCUMENT`)
- Android Sharesheet में file share
- Android App Info और App Settings खोलने की Native API
- GitHub Actions workflow से Debug APK build
- ऐप के लिए INTERNET permission हटाने का प्रयास; ऐप की local assets offline पैक होती हैं

## केवल मोबाइल से GitHub पर अपलोड — सबसे आसान तरीका

इस तरीके में फोन पर ZIP extract करके ढेर सारे folders upload करने की जरूरत नहीं है।

1. GitHub पर नया **Public** repository बनाएं, जैसे `likho-pro-android`.
2. Repository में `Add file` → `Upload files` दबाकर `Likho_Pro_Professional_Android_Project.zip` upload करें और Commit करें।
3. अब `Add file` → `Create new file` दबाएं।
4. नाम लिखें: `.github/workflows/build-apk.yml`
5. इस ZIP के अंदर वाली `GITHUB_WORKFLOW_FOR_REPO.yml` फाइल खोलें और उसका पूरा code copy करके GitHub की नई file में paste करें।
6. `Commit changes` दबाएं। फिर Repository के `Actions` tab में Build शुरू होगा। जरूरत हो तो `Build Likho Pro APK from ZIP` → `Run workflow` दबाएं।
7. Build सफल होने पर run खोलें और `Artifacts` में `Likho-Pro-Android-APK` डाउनलोड करें।
8. Artifact ZIP को Files app से extract करें और `app-debug.apk` install करें।

ध्यान दें: GitHub workflow file का path बिल्कुल `.github/workflows/build-apk.yml` होना चाहिए। Repository के root में project ZIP का नाम भी बिल्कुल `Likho_Pro_Professional_Android_Project.zip` होना चाहिए।

## जरूरी: GitHub upload का सही रूप

Repository root में ये चीजें सीधे दिखनी चाहिए:
- `package.json`
- `capacitor.config.json`
- `www/index.html`
- `.github/workflows/build-apk.yml`
- `scripts/patch-android.mjs`
- `android-template/...`

गलती से पूरा project एक और अंदर वाले folder में upload न करें।

## File Manager से खोलना

इस ऐप में Android manifest के लिए MIME filters दिए गए हैं: PDF, DOCX, DOC, TXT, Markdown, HTML, RTF, PPTX, PPT और Images। Android File Manager में file चुनें → Open with → Likho Pro (यदि file manager MIME type सही देता है)।

पहली बार Android पूछ सकता है कि किस app से खोलना है। आप चाहें तो Likho Pro को default बना सकते हैं।

## Import / Save As / Share

- Import File button Android document picker खोलेगा।
- Export का document generation logic मूल HTML से रखा गया है। Android पर download/save action को Save As picker में भेजा गया है।
- Share action Android Sharesheet खोलेगा।
- Shared/opened files को ऐप के मौजूदा importer में भेजा जाता है।

## Offline और सीमाएँ

- HTML में कोई remote CDN stylesheet/script नहीं मिली; editor assets app में bundled हैं।
- ऐप का मुख्य editor, local storage और IndexedDB device पर रहते हैं।
- पहली बार GitHub पर APK build करने के लिए इंटरनेट चाहिए। APK install होने के बाद editor का local काम इंटरनेट के बिना चलना चाहिए।
- बाहरी cloud backup, online sync, web links, online fonts या external URLs offline नहीं होंगे।
- Native plugin 30 MB तक की एक file read/save/share करने की सीमा रखता है। बड़ी files के लिए streaming implementation चाहिए।
- PDF preview Android WebView की PDF support पर निर्भर हो सकता है। PDF file को import/store करने और system PDF viewer में खोलने की क्षमता अलग है।
- पुराने `.doc` और कुछ complex DOCX/PPTX formats की rendering HTML parser की मौजूदा क्षमता पर निर्भर है; हर Microsoft Office layout की पूर्ण compatibility का दावा नहीं है।
- Android file-open support MIME type पर निर्भर है; कुछ file managers file type सही report नहीं करते।
- App Lock और password-protected documents का व्यवहार HTML implementation पर निर्भर है। यह Android device-level encryption का विकल्प नहीं है।
- Debug APK testing के लिए है। सार्वजनिक वितरण के लिए अपनी सुरक्षित release signing key बनाएं और उसका backup रखें।
- यह project template तैयार किया गया है; इस environment में Android SDK/Gradle build और वास्तविक फोन पर परीक्षण नहीं चलाया गया। GitHub Actions build result देखकर ही APK को install करें। Build error आए तो पूरा log साझा करें।

## Export code

मूल HTML के PDF/DOCX/PPTX export generators को नहीं बदला गया। `save()` output path को Android Save As picker से जोड़ा गया है; export content generation उसी HTML से है।

## Package details

- App name: Likho Pro
- Application ID: `com.likhopro.app`
- Capacitor major: 8
- Java: 21
- GitHub Actions: Ubuntu runner
