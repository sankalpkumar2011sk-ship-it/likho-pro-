package com.likhopro.app;

import android.content.Intent;
import android.content.ClipData;
import android.content.ContentResolver;
import android.content.Context;
import android.database.Cursor;
import android.net.Uri;
import android.os.Build;
import android.provider.OpenableColumns;
import android.provider.Settings;
import android.util.Base64;

import androidx.activity.result.ActivityResult;
import androidx.core.content.FileProvider;

import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.ActivityCallback;
import com.getcapacitor.annotation.CapacitorPlugin;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.FileOutputStream;
import java.util.Locale;

@CapacitorPlugin(name = "NativeFiles")
public class NativeFilesPlugin extends Plugin {
    private static final int MAX_FILE_BYTES = 30 * 1024 * 1024;

    @PluginMethod
    public void getPendingOpen(PluginCall call) {
        Intent intent = getActivity().getIntent();
        Uri uri = getIncomingUri(intent);
        if (uri == null) {
            JSObject empty = new JSObject();
            empty.put("opened", false);
            call.resolve(empty);
            return;
        }
        call.resolve(uriInfo(uri, intent.getType()));
    }

    @PluginMethod
    public void pickFile(PluginCall call) {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("*/*");
        intent.putExtra(Intent.EXTRA_MIME_TYPES, new String[] {
            "application/pdf",
            "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
            "application/msword",
            "text/plain",
            "text/markdown",
            "text/html",
            "application/rtf",
            "application/vnd.openxmlformats-officedocument.presentationml.presentation",
            "application/vnd.ms-powerpoint",
            "image/*"
        });
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
        startActivityForResult(call, intent, "pickFileResult");
    }

    @ActivityCallback
    private void pickFileResult(PluginCall call, ActivityResult result) {
        if (call == null) return;
        if (result.getResultCode() != android.app.Activity.RESULT_OK || result.getData() == null
                || result.getData().getData() == null) {
            call.reject("User cancelled");
            return;
        }
        Uri uri = result.getData().getData();
        try {
            getContext().getContentResolver().takePersistableUriPermission(uri,
                Intent.FLAG_GRANT_READ_URI_PERMISSION);
        } catch (Exception ignored) {}
        call.resolve(uriInfo(uri, getContext().getContentResolver().getType(uri)));
    }

    @PluginMethod
    public void readFile(PluginCall call) {
        String raw = call.getString("uri");
        if (raw == null || raw.trim().isEmpty()) {
            call.reject("Missing file URI");
            return;
        }
        try {
            Uri uri = Uri.parse(raw);
            byte[] bytes = readBytes(uri);
            JSObject ret = uriInfo(uri, getContext().getContentResolver().getType(uri));
            ret.put("base64", Base64.encodeToString(bytes, Base64.NO_WRAP));
            call.resolve(ret);
        } catch (Exception e) {
            call.reject("Could not read file: " + e.getMessage(), e);
        }
    }

    @PluginMethod
    public void saveFile(PluginCall call) {
        String name = call.getString("name", "LikhoPro-Document");
        String mime = call.getString("mimeType", "application/octet-stream");
        Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType(mime);
        intent.putExtra(Intent.EXTRA_TITLE, name);
        startActivityForResult(call, intent, "saveFileResult");
    }

    @ActivityCallback
    private void saveFileResult(PluginCall call, ActivityResult result) {
        if (call == null) return;
        if (result.getResultCode() != android.app.Activity.RESULT_OK || result.getData() == null
                || result.getData().getData() == null) {
            call.reject("User cancelled");
            return;
        }
        try {
            String base64 = call.getString("base64");
            if (base64 == null) throw new Exception("No file content received");
            byte[] bytes = Base64.decode(base64, Base64.DEFAULT);
            if (bytes.length > MAX_FILE_BYTES) throw new Exception("File is larger than 30 MB");
            Uri uri = result.getData().getData();
            try (OutputStream out = getContext().getContentResolver().openOutputStream(uri, "w")) {
                if (out == null) throw new Exception("Cannot open destination");
                out.write(bytes);
                out.flush();
            }
            JSObject ret = new JSObject();
            ret.put("saved", true);
            ret.put("uri", uri.toString());
            call.resolve(ret);
        } catch (Exception e) {
            call.reject("Could not save file: " + e.getMessage(), e);
        }
    }

    @PluginMethod
    public void shareFile(PluginCall call) {
        try {
            String name = call.getString("name", "LikhoPro-file");
            String mime = call.getString("mimeType", "application/octet-stream");
            String base64 = call.getString("base64");
            if (base64 == null) throw new Exception("No file content");
            byte[] bytes = Base64.decode(base64, Base64.DEFAULT);
            if (bytes.length > MAX_FILE_BYTES) throw new Exception("File is larger than 30 MB");
            File folder = new File(getContext().getCacheDir(), "shared");
            if (!folder.exists()) folder.mkdirs();
            String safeName = name.replaceAll("[^A-Za-z0-9._-]", "_");
            File file = new File(folder, safeName);
            try (FileOutputStream out = new FileOutputStream(file)) { out.write(bytes); }
            Uri contentUri = FileProvider.getUriForFile(getContext(),
                getContext().getPackageName() + ".fileprovider", file);
            Intent send = new Intent(Intent.ACTION_SEND);
            send.setType(mime);
            send.putExtra(Intent.EXTRA_STREAM, contentUri);
            send.setClipData(ClipData.newUri(getContext().getContentResolver(), name, contentUri));
            send.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            getActivity().startActivity(Intent.createChooser(send, "Share with"));
            call.resolve();
        } catch (Exception e) {
            call.reject("Could not share file: " + e.getMessage(), e);
        }
    }

    @PluginMethod
    public void openAppSettings(PluginCall call) {
        Intent intent = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
            Uri.parse("package:" + getContext().getPackageName()));
        getActivity().startActivity(intent);
        call.resolve();
    }

    @PluginMethod
    public void getAppInfo(PluginCall call) {
        JSObject ret = new JSObject();
        try {
            android.content.pm.PackageInfo info = getContext().getPackageManager()
                .getPackageInfo(getContext().getPackageName(), 0);
            ret.put("name", getContext().getApplicationInfo().loadLabel(getContext().getPackageManager()).toString());
            ret.put("packageName", getContext().getPackageName());
            ret.put("versionName", info.versionName == null ? "" : info.versionName);
            ret.put("versionCode", Build.VERSION.SDK_INT >= 28 ? info.getLongVersionCode() : info.versionCode);
            ret.put("androidVersion", Build.VERSION.RELEASE);
        } catch (Exception ignored) {}
        call.resolve(ret);
    }

    @Override
    protected void handleOnNewIntent(Intent intent) {
        super.handleOnNewIntent(intent);
        Uri uri = getIncomingUri(intent);
        if (uri != null) {
            JSObject data = uriInfo(uri, intent.getType());
            notifyListeners("fileOpened", data);
        }
    }

    private Uri getIncomingUri(Intent intent) {
        if (intent == null) return null;
        Uri uri = intent.getData();
        if (uri == null && intent.getClipData() != null && intent.getClipData().getItemCount() > 0) {
            uri = intent.getClipData().getItemAt(0).getUri();
        }
        if (uri == null) {
            Object stream = intent.getParcelableExtra(Intent.EXTRA_STREAM);
            if (stream instanceof Uri) uri = (Uri) stream;
        }
        return uri;
    }

    private JSObject uriInfo(Uri uri, String mime) {
        JSObject ret = new JSObject();
        ret.put("opened", true);
        ret.put("uri", uri.toString());
        ret.put("name", displayName(uri));
        ret.put("mimeType", mime == null ? "application/octet-stream" : mime);
        return ret;
    }

    private String displayName(Uri uri) {
        String name = "Imported file";
        try (Cursor cursor = getContext().getContentResolver().query(uri, null, null, null, null)) {
            if (cursor != null && cursor.moveToFirst()) {
                int index = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME);
                if (index >= 0) name = cursor.getString(index);
            }
        } catch (Exception ignored) {}
        return name;
    }

    private byte[] readBytes(Uri uri) throws Exception {
        ContentResolver resolver = getContext().getContentResolver();
        try (InputStream in = resolver.openInputStream(uri);
             ByteArrayOutputStream out = new ByteArrayOutputStream()) {
            if (in == null) throw new Exception("Cannot open file");
            byte[] buffer = new byte[8192];
            int total = 0, n;
            while ((n = in.read(buffer)) > 0) {
                total += n;
                if (total > MAX_FILE_BYTES) throw new Exception("File is larger than 30 MB");
                out.write(buffer, 0, n);
            }
            return out.toByteArray();
        }
    }
}
